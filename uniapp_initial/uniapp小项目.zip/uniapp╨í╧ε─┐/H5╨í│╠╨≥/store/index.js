import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
	state:{
		menuBarUrl:[
			{
				_id:1,
				name:'CSS',
				url:'/static/icon/css.png'
			},
			{
				_id:2,
				name:'HTML',
				url:'/static/icon/html.png'
			},
			{
				_id:3,
				name:'Java',
				url:'/static/icon/java.png'
			},
			{
				_id:4,
				name:'JavaScript',
				url:'/static/icon/JavaScript.png'
			},
			{
				_id:5,
				name:'MongoDB',
				url:'/static/icon/mongdb.png'
			},
			{
				_id:6,
				name:'MySQL',
				url:'/static/icon/MySQL.png'
			},
			{
				_id:7,
				name:'python',
				url:'/static/icon/py.png'
			},
			{
				_id:8,
				name:'React',
				url:'/static/icon/react.png'
			},
			{
				_id:9,
				name:'webpack',
				url:'/static/icon/webpack.png'
			},
			{
				_id:10,
				name:'Vue',
				url:'/static/icon/Vue.png'
			},
		]
	},
	mutations:{
		
	},
	actions:{
		
	}
})

export default store