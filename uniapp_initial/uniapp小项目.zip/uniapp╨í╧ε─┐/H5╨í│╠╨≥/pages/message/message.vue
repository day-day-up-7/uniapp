<template>
	<view>
		<uni-list>
			<uni-list :border="true" v-for="message in messageList" :key="message._id">
				<!-- 头像显示角标 -->
				<uni-list-chat 
				:title="message.title" 
				:avatar="message.avatar" 
				note="您收到一条新的消息" 
				time="2020-02-02 20:20" 
				badge-positon="left" 
				badge-text="99"
				></uni-list-chat>
			</uni-list>
		</uni-list>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				messageList:[
					{
						_id:1,
						title:'男孩',
						avatar:'/static/header/1.png'
					},
					{
						_id:2,
						title:'女孩',
						avatar:'/static/header/2.png'
					},
					{
						_id:3,
						title:'女客服',
						avatar:'/static/header/3.png'
					},
					{
						_id:4,
						title:'男客服',
						avatar:'/static/header/4.png'
					},
					{
						id:5,
						title:'男士',
						avatar:'/static/header/5.png'
					},
					{
						_id:6,
						title:'女士',
						avatar:'/static/header/6.png'
					},
				]
			}
		},
		// 下拉监听
		onPullDownRefresh() {
			setTimeout(function () {
				// 结束下拉
				uni.stopPullDownRefresh();
			}, 1000);
		},
		methods: {
			
		}
	}
</script>

<style lang="less" scoped>
	
</style>
