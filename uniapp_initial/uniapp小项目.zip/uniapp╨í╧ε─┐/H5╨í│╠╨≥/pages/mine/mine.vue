<template>
	<view>
		<view class="header">
			<image class="backgroundImage" :src="userInfo.background" mode="widthFix"></image>
			<view class="user">
				<image class="headerImage" :src="userInfo.head" mode="widthFix"></image>
				<view class="userMessage">
					<text class="userName">{{ userInfo.name }}</text>
					<text class="userAccountNumber">账号：{{ userInfo.accountNumber }}</text>
				</view>
			</view>
		</view>
		<navigation :navigationList="navigationTop" :num="navigationTop.length"></navigation>
		<text class="headline">我的订单</text>
		<navigation :navigationList="navigationBotton" :num="navigationBotton.length"></navigation>
		<otherSet></otherSet>
	</view>
</template>

<script>
	import navigation from '../../component/navigation/navigation.vue'
	import otherSet from '../../component/otherSet/otherSet.vue'
	
	import { reqUserInfo } from '../../API/index.js'
	export default {
		components:{ navigation, otherSet },
		data() {
			return {
				userInfo:{},
				navigationTop:[
					{
						_id:1,
						name:'收藏',
						url:'/static/navigation/收藏.png'
					},
					{
						_id:2,
						name:'关注',
						url:'/static/navigation/店铺关注.png'
					},
					{
						_id:3,
						name:'足迹',
						url:'/static/navigation/历史记录.png'
					}
				],
				navigationBotton:[
					{
						_id:1,
						name:'待付款',
						url:'/static/navigation/待付款.png'
					},
					{
						_id:2,
						name:'待发货',
						url:'/static/navigation/待发货.png'
					},
					{
						_id:3,
						name:'待收货',
						url:'/static/navigation/待收货.png'
					},
					{
						_id:4,
						name:'退货/售后',
						url:'/static/navigation/退货售后.png'
					}
				]
			}
		},
		mounted() {
			this.requserData()
		},
		methods: {
			async requserData() {
				const result = await reqUserInfo()
				const data = result.data.data
				const [userInfo] = data
				this.userInfo = userInfo
			}
		}
	}
</script>

<style lang="less" scoped>
	.header {
		position: relative;
		.backgroundImage {
			width: 750rpx;
		}
		.user {
			z-index: 11;
			position: absolute;
			top: 200rpx;
			left: 30rpx;
			display: flex;
			.headerImage {
				width: 100rpx;
				border: 1rpx solid white;
			}
			.userMessage {
				display: flex;
				flex-direction: column;
				.userName {
					margin-top: auto;
					display: block;
					margin-left: 20rpx;
					color: white;
				}
				.userAccountNumber {
					font-size: 20rpx;
					display: block;
					margin-left: 20rpx;
					color: white;
				}
			}
		}
	}
	.headline {
		margin: 20rpx 0rpx 20rpx 40rpx;
		display: block;
		font-weight: bold;
	}
</style>
