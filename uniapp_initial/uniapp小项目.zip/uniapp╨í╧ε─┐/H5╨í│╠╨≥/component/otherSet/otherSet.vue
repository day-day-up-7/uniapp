<template>
	<view>
		<uni-section title="其他" titleFontSize="40rpx">
			<uni-list>
				<uni-list-item thumbSize="sm" showArrow clickable title="会员中心" thumb="/static/otherSet/会员.png" />
				<uni-list-item thumbSize="sm"showArrow clickable title="我的礼劵" thumb="/static/otherSet/优惠券.png"/>
				<uni-list-item thumbSize="sm" showArrow clickable title="我的电子书" thumb="/static/otherSet/电子书.png"/>
				<uni-list-item thumbSize="sm" showArrow clickable title="我的礼品" thumb="/static/otherSet/礼品.png"/>
				<uni-list-item thumbSize="sm" showArrow clickable title="联系客服" thumb="/static/otherSet/在线客服.png"/>
				<uni-list-item thumbSize="sm" showArrow clickable title="设置" thumb="/static/otherSet/设置.png"/>
			</uni-list>
		</uni-section>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
